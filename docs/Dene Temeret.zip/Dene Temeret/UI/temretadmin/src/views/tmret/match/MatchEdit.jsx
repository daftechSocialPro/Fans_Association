import React, { useState } from 'react'
import axios from 'axios'
import {
    CButton,
    CCard,
    CCardBody,
    CCardHeader,
    CCol,
    CForm,
    CFormInput,
    CRow,
    CCallout
} from '@coreui/react'
import { urlMatch } from 'src/endpoints'
import { customToast } from '../../../components/customToast'
import { useNavigate } from 'react-router-dom'
import {useLocation} from 'react-router-dom'

function MatchEdit({setIsLodding}) {

    const location = useLocation()

    const match = location.state.match;

    

    const [team1, setTeam1] = useState(match&&match.team1)
    const [team1Abb, setTeam1Abb] = useState(match && match.team1Abb)
    const [team2, setTeam2] = useState(match && match.team2)
    const [team2Abb, setTeam2Abb] = useState(match && match.team2Abb)
    const [date, setDate] = useState(match && match.date)
    const [time, setTime] = useState(match && match.time)
    const [matchWeek, setMatchWeek] = useState(match && match.matchWeek)


    const navigate = useNavigate();

    const handleSubmit = async (event) => {
        event.preventDefault()
        setIsLodding(true)


        try {


            axios.put(`${urlMatch}`,

                {
                    team1: team1,
                    team1Abb: team1Abb,
                    team2: team2,
                    team2Abb: team2Abb,
                    date: date,
                    time: time,
                    matchWeek: matchWeek,
                    ID: match&& match.id

                })

                .then((res) => {
                    setTeam1('')
                    setTeam1Abb('')
                    setTeam2('')
                    setTeam2Abb('')
                    setDate('')
                    setTime('')
                    setMatchWeek(0);
                    setIsLodding(false)
                    customToast("Match Successfully updated", 0)
                    navigate("/match")

                }
                ).catch((err) => {
                    setIsLodding(false)
                    customToast(err, 1)
                    console.error(err)
                })

        }
        catch (error) {
            customToast(error, 1)
            console.error(error)

        }
    }


  return (
    <CRow>
    <CCol xs={12}>
        <CCallout className='bg-white'>

            Edit match

        </CCallout>

    </CCol>
    <CCol xs={12}>
        <CCard className="mb-4">
            <CCardHeader style={{ backgroundColor: '#232324de', color: '#e99313' }}>
                <strong>Edit </strong> <small>Match</small>
            </CCardHeader>
            <CCardBody>
                <CForm
                    className="row g-3 needs-validation"

                    validated
                    onSubmit={handleSubmit}
                >


                    <CCol xs="2">
                        <CFormInput
                            type="number"
                            placeholder="game match week"

                            required
                            value={matchWeek}
                            onChange={(e) => setMatchWeek(e.target.value)}

                        />

                    </CCol>

                    <CCol xs="2">
                        <CFormInput
                            type="text"
                            placeholder="Team 1"

                            required
                            value={team1}
                            onChange={(e) => setTeam1(e.target.value)}

                        />

                    </CCol>
                    <CCol xs="1">
                        <CFormInput
                            type="text"
                            placeholder="Team 1 abbreviation"

                            required
                            value={team1Abb}
                            onChange={(e) => setTeam1Abb(e.target.value)}

                        />

                    </CCol>
                    <CCol xs="2">
                        <CFormInput
                            type="date"
                            

                            required
                            value={date}
                            onChange={(e) => setDate(e.target.value)}

                        />

                    </CCol>
                    <CCol xs="2">
                        <CFormInput
                            type="time"
                            

                            required
                            value={time}
                            onChange={(e) => setTime(e.target.value)}

                        />

                    </CCol>
                    <CCol xs="2">
                        <CFormInput
                            type="text"
                            placeholder="Team 2"

                            required
                            value={team2}
                            onChange={(e) => setTeam2(e.target.value)}

                        />

                    </CCol>
                    <CCol xs="1">
                        <CFormInput
                            type="text"
                            placeholder="Team 2 abbreviation"

                            required
                            value={team2Abb}
                            onChange={(e) => setTeam2Abb(e.target.value)}

                        />

                    </CCol>



                    <hr />
                    <div className='d-flex justify-content-end'>
                        <CCol xs="auto" >

                            <CButton style={{ backgroundColor: '#232324de', color: '#e99313', borderColor: '#e99313' }} type="submit">
                                Update
                            </CButton>
                        </CCol>

                    </div>



                </CForm>
            </CCardBody>
        </CCard>
    </CCol>
</CRow>
  )
}

export default MatchEdit