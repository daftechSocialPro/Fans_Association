import React, { useState, useEffect } from 'react'
import axios from 'axios'
import dateFormat from 'dateformat'
import {
  CCol,
  CRow,
  CCallout,
  CButton,
  CCard,
  CCardBody,
  CCardHeader,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CForm,
  CFormLabel,
  CFormInput,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import { cilAlignCenter, cilImage, cilPenAlt, cilTrash } from '@coreui/icons'
import { assetUrl, urlAdvert } from 'src/endpoints'
import { MDBCol, MDBRow, MDBCard, MDBCardBody, MDBCardImage } from 'mdb-react-ui-kit'
import { customToast } from 'src/components/customToast'

import ReactQuill, { Quill } from 'react-quill'
import 'react-quill/dist/quill.snow.css'
import ImageResize from 'quill-image-resize-module-react'

Quill.register('modules/imageResize', ImageResize)

function Advert({ setIsLodding }) {
  const [advert, setAdvert] = useState([])
  const [visibleXL, setVisibleXL] = useState(false)
  const [viewImg, setViewImg] = useState(null)

  useEffect(() => {
    getAdvert()
  }, [advert])

  const getAdvert = () => {
    axios.get(urlAdvert).then((res) => setAdvert(res.data))
  }

  const [description, setDescription] = useState('')
  const [name, setName] = useState('')
  const [fromDate, setFromDate] = useState('')
  const [toDate, setToDate] = useState('')
  const [img, setImg] = useState('')

  const photoInputHandler = (event) => {
    setImg(event.target.files[0])
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setIsLodding(true)

    const formData = new FormData()

    formData.append('Photo', img)
    formData.set('Name', name)
    formData.set('FromDate', fromDate)
    formData.set('ToDate', toDate)
    formData.set('Description', description)

    const form = event.currentTarget
    if (form.checkValidity() === false) {
      event.stopPropagation()
    }

    try {
      await axios
        .post(urlAdvert, formData)
        .then((res) => {
          setIsLodding(false)
          setVisibleXL(false)
          setName('')
          setDescription('')
          setImg('')
          setFromDate('')
          setToDate('')
          customToast('Advert Successfully created', 0)
        })
        .catch((err) => {
          setIsLodding(false)
          customToast(err, 1)
        })
    } catch (error) {
      setIsLodding(false)
      customToast(error, 1)
      console.error(error)
    }
  }
  const modules = {
    toolbar: [
      [{ header: '1' }, { header: '2' }, { font: [] }],
      [{ size: [] }],
      ['bold', 'italic', 'underline', 'strike', 'blockquote'],
      [{ list: 'ordered' }, { list: 'bullet' }, { indent: '-1' }, { indent: '+1' }],
      ['link', 'image', 'video'],
      ['clean'],
    ],
    clipboard: {
      matchVisual: false,
    },
    imageResize: {
      parchment: Quill.import('parchment'),
      modules: ['Resize', 'DisplaySize'],
    },
  }

  const formats = [
    'header',
    'font',
    'size',
    'bold',
    'italic',
    'underline',
    'strike',
    'blockquote',
    'list',
    'bullet',
    'indent',
    'link',
    'image',
    'video',
  ]

  const getImage = (item) => {
    return `${assetUrl}/${item}`
  }

  const deleteAd = (item) => {
    console.log('ad', item)
    setIsLodding(true)
    axios
      .delete(`${urlAdvert}?advertId=${item}`)
      .then((res) => {
        getAdvert();
        setIsLodding(false)
        customToast('successfully Deleted', 0)
      })
      .catch((err) => {
        setIsLodding(false)
        customToast('something went wrong', 1)
      })
  }
  return (
    <>
      <CModal size="xl" visible={visibleXL} onClose={() => setVisibleXL(false)}>
        <CModalHeader
          style={{
            backgroundColor: '#232324de',
            color: '#e99313',
          }}
        >
          <CModalTitle>Add Advert </CModalTitle>
        </CModalHeader>
        <CModalBody>
          <CCardBody>
            <MDBRow>
              <MDBCol lg="12">
                <MDBCard className="mb-4">
                  <MDBCardBody>
                    <CRow>
                      <CCol xs={12}>
                        <CCallout className="bg-white">Advert Add</CCallout>
                      </CCol>
                      <CCol xs={12}>
                        <CCard className="mb-4">
                          <CCardBody>
                            <CForm
                              className="row g-3 needs-validation"
                              validated
                              onSubmit={handleSubmit}
                            >
                              <CCol md={3}></CCol>
                              <CCol md={6}>
                                {img && (
                                  <img
                                    style={{
                                      maxHeight: '400px',
                                      width: '100%',
                                      border: 'solid #e99313',
                                      borderRadius: '20px',
                                    }}
                                    src={URL.createObjectURL(img)}
                                  />
                                )}
                              </CCol>
                              <CCol md={3}></CCol>

                              <CCol md={3}>
                                <CFormLabel htmlFor="formFileLg">Ad Photo</CFormLabel>
                                <CFormInput
                                  type="file"
                                  size="sm"
                                  accept="image/*"
                                  onChange={photoInputHandler}
                                  required
                                  id="formFileLg"
                                />
                              </CCol>

                              <CCol md={3}>
                                <CFormInput
                                  type="text"
                                  placeholder="name..."
                                  label="Name"
                                  required
                                  value={name}
                                  onChange={(e) => setName(e.target.value)}
                                />
                              </CCol>
                              <CCol md={3}>
                                <CFormInput
                                  type="date"
                                  label="From Date"
                                  required
                                  value={fromDate}
                                  onChange={(e) => setFromDate(e.target.value)}
                                />
                              </CCol>
                              <CCol md={3}>
                                <CFormInput
                                  type="date"
                                  label="To Date"
                                  required
                                  value={toDate}
                                  onChange={(e) => setToDate(e.target.value)}
                                />
                              </CCol>

                              <CCol xs={12}>
                                <CFormLabel htmlFor="formFileLg">Description</CFormLabel>
                                <ReactQuill
                                  formats={formats}
                                  modules={modules}
                                  theme="snow"
                                  required
                                  value={description}
                                  onChange={setDescription}
                                />
                              </CCol>

                              <CCol xs={12} className="d-flex justify-content-end">
                                <CButton
                                  size="lg"
                                  style={{
                                    backgroundColor: '#232324de',
                                    color: '#e99313',
                                    borderColor: '#e99313',
                                  }}
                                  type="submit"
                                >
                                  Submit
                                </CButton>
                              </CCol>
                            </CForm>
                          </CCardBody>
                        </CCard>
                      </CCol>
                    </CRow>
                  </MDBCardBody>
                </MDBCard>
              </MDBCol>
            </MDBRow>
          </CCardBody>
        </CModalBody>
      </CModal>

      <CModal size="xl" visible={viewImg} onClose={() => setViewImg(null)}>
        <CModalHeader
          style={{
            backgroundColor: '#232324de',
            color: '#e99313',
          }}
        >
          <CModalTitle>Advert Picture </CModalTitle>
        </CModalHeader>
        <CModalBody>
          <CCardBody>
            <MDBRow>
              <MDBCol lg="12">
                <MDBCard className="mb-4">
                  <MDBCardBody>
                    <CRow>
                      <CCol xs={12}>
                        <CCallout className="bg-white">Advert Picture</CCallout>
                      </CCol>
                      <CCol xs={12}>
                        <CCard className="mb-4">
                          <CCardBody>
                            <CForm
                              className="row g-3 needs-validation"
                              validated
                              onSubmit={handleSubmit}
                            >
                              <CCol md={3}></CCol>
                              <CCol md={6}>
                                <img
                                  style={{
                                    border: 'solid #e99313',
                                    borderRadius: '20px',
                                  }}
                                  src={getImage(viewImg)}
                                />
                              </CCol>
                              <CCol md={3}></CCol>
                            </CForm>
                          </CCardBody>
                        </CCard>
                      </CCol>
                    </CRow>
                  </MDBCardBody>
                </MDBCard>
              </MDBCol>
            </MDBRow>
          </CCardBody>
        </CModalBody>
      </CModal>

      <CRow>
        <CCol xs={12}>
          <CCallout className="bg-white"></CCallout>
        </CCol>
        <CCol xs={12}>
          <CCard className="mb-4">
            <CCardHeader className="" style={{ backgroundColor: '#232324de', color: '#e99313' }}>
              <CRow>
                <CCol sm={10}>
                  <strong>Advert</strong> <small>List</small>
                </CCol>
                <CCol sm={2} className="d-flex justify-content-end">
                  <CButton
                    className="text-right bg-white"
                    onClick={() => setVisibleXL(true)}
                    style={{ color: '#e99313', borderColor: '#e99313' }}
                    type="submit"
                  >
                    Add Advert
                  </CButton>
                </CCol>
              </CRow>
            </CCardHeader>

            <CCardBody>
              <CTable align="middle" className="mb-0 border" hover responsive>
                <CTableHead color="light">
                  <CTableRow>
                    <CTableHeaderCell className="text-center">
                      <CIcon icon={cilImage} />
                    </CTableHeaderCell>
                    <CTableHeaderCell>Name</CTableHeaderCell>
                    <CTableHeaderCell>Description</CTableHeaderCell>
                    <CTableHeaderCell>From Date</CTableHeaderCell>
                    <CTableHeaderCell>To Date</CTableHeaderCell>

                    <CTableHeaderCell>Details</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {advert.map((item, index) => (
                    <CTableRow v-for="item in tableItems" key={index}>
                      <CTableDataCell className="text-center">
                        <MDBCardImage
                          onClick={() => setViewImg(item.adPhoto)}
                          src={getImage(item.adPhoto)}
                          alt="avatar"
                          style={{
                            width: '120px',
                            height: '80px',
                            borderRadius: '20px',
                            border: 'solid #e99313',
                          }}
                          fluid
                        />
                      </CTableDataCell>
                      <CTableDataCell>{item.name}</CTableDataCell>
                      <CTableDataCell>
                        <div dangerouslySetInnerHTML={{ __html: item.description }}></div>
                      </CTableDataCell>

                      <CTableDataCell>{dateFormat(item.fromDate)}</CTableDataCell>
                      <CTableDataCell>{dateFormat(item.toDate)}</CTableDataCell>

                      <CTableDataCell>
                        <CButton
                          style={{
                            backgroundColor: '#232324de',
                            color: '#e99313',
                            borderColor: '#e99313',
                          }}
                          onClick={() => {
                            deleteAd(item.id)
                            //setDegafi(item)
                          }}
                        >
                          <CIcon icon={cilTrash} />
                          &nbsp; Remove
                        </CButton>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  )
}

export default Advert
