import React, { useState, useEffect } from 'react'
import axios from 'axios'
import dateFormat from 'dateformat'
import {
  CCol,
  CRow,
  CCallout,
  CButton,
  CCard,
  CCardBody,
  CCardHeader,
  CTable,
  CTableBody,
  CTableDataCell,
  CTableHead,
  CTableHeaderCell,
  CTableRow,
  CModal,
  CModalHeader,
  CModalTitle,
  CModalBody,
  CForm,
  CFormLabel,
  CFormInput,
  CFormSelect,
} from '@coreui/react'
import CIcon from '@coreui/icons-react'
import {  cilImage,  cilTrash } from '@coreui/icons'
import { assetUrl,  urlDegafiSetting, urlMahber } from 'src/endpoints'
import { MDBCol, MDBRow, MDBCard, MDBCardBody, MDBCardImage } from 'mdb-react-ui-kit'
import { customToast } from 'src/components/customToast'

import ReactQuill, { Quill } from 'react-quill'
import 'react-quill/dist/quill.snow.css'
import ImageResize from 'quill-image-resize-module-react'

Quill.register('modules/imageResize', ImageResize)

function DegafiSetting({ user,setIsLodding }) {
  const [degafiSetting, setDegafiSetting] = useState([])
  const [visibleXL, setVisibleXL] = useState(false)
  const [mahber, setMahber] = useState([])

  useEffect(() => {
    getDegafiSetting()
    getMahber()
  }, [])

  const getDegafiSetting = () => {
    axios.get(urlDegafiSetting).then((res) => {
    setDegafiSetting(res.data)
   
    }
    )
  }
  const getMahber = () => {
    axios.get(urlMahber).then((res) =>{ 
      setMahber(res.data.filter(m=>m.userId==user.id)[0])
      console.log("mahber",mahber)})
  }

  const [description, setDescription] = useState('')
  const [name, setName] = useState('')
  const [money, setMoney] = useState('')
  const [paymentStyle, setPaymentStyle] = useState('')


  const handleSubmit = async (event) => {
    event.preventDefault()
    setIsLodding(true)

  console.log({
    name:name,
    money:money,
    paymentStyle:paymentStyle,
    description:description,
    mahberId:mahber.id
  })

    const form = event.currentTarget
    if (form.checkValidity() === false) {
      event.stopPropagation()
    }

    try {
      await axios
        .post(urlDegafiSetting, {
          name:name,
          money:money,
          paymentStyle:paymentStyle,
          description:description,
          mahberId:mahber.id
        })
        .then((res) => {
          setIsLodding(false)
          setVisibleXL(false)
          setName('')
          setDescription('')
          setMoney('')
          setPaymentStyle('')
        
          customToast('Degafi Setting Successfully created', 0)
        })
        .catch((err) => {
          setIsLodding(false)
          customToast(err, 1)
        })
    } catch (error) {
      setIsLodding(false)
      customToast(error, 1)
      console.error(error)
    }
  }
  const modules = {
    toolbar: [
      [{ header: '1' }, { header: '2' }, { font: [] }],
      [{ size: [] }],
      ['bold', 'italic', 'underline', 'strike', 'blockquote'],
      [{ list: 'ordered' }, { list: 'bullet' }, { indent: '-1' }, { indent: '+1' }],
      ['link', 'image', 'video'],
      ['clean'],
    ],
    clipboard: {
      matchVisual: false,
    },
    imageResize: {
      parchment: Quill.import('parchment'),
      modules: ['Resize', 'DisplaySize'],
    },
  }

  const formats = [
    'header',
    'font',
    'size',
    'bold',
    'italic',
    'underline',
    'strike',
    'blockquote',
    'list',
    'bullet',
    'indent',
    'link',
    'image',
    'video',
  ]

  
  const deleteDegafi = (item) => {
    console.log('ad', item)
    setIsLodding(true)
    axios
      .delete(`${urlDegafiSetting}?desetingId=${item}`)
      .then((res) => {
        getDegafiSetting();
        setIsLodding(false)
        customToast('successfully Deleted', 0)
      })
      .catch((err) => {
        setIsLodding(false)
        customToast('something went wrong', 1)
      })
  }
  return (
    <>
      <CModal size="xl" visible={visibleXL} onClose={() => setVisibleXL(false)}>
        <CModalHeader
          style={{
            backgroundColor: '#232324de',
            color: '#e99313',
          }}
        >
          <CModalTitle>Add Degafi Setting </CModalTitle>
        </CModalHeader>
        <CModalBody>
          <CCardBody>
            <MDBRow>
              <MDBCol lg="12">
                <MDBCard className="mb-4">
                  <MDBCardBody>
                    <CRow>
                      <CCol xs={12}>
                        <CCallout className="bg-white">Degafi Setting Add</CCallout>
                      </CCol>
                      <CCol xs={12}>
                        <CCard className="mb-4">
                          <CCardBody>
                            <CForm
                              className="row g-3 needs-validation"
                              validated
                              onSubmit={handleSubmit}
                            >
                             

                             

                              <CCol md={4}>
                                <CFormInput
                                  type="text"
                                  placeholder="name..."
                                  label="Name"
                                  required
                                  value={name}
                                  onChange={(e) => setName(e.target.value)}
                                />
                              </CCol>
                              <CCol md={4}>
                                <CFormInput
                                  type="text"
                                  label="Money"
                                  required
                                  value={money}
                                  onChange={(e) => setMoney(e.target.value)}
                                />
                              </CCol>
                              <CCol md={4}>
                                <CFormSelect
                                  
                                  label="Payment Style"
                                  required
                                  value={paymentStyle}
                                  onChange={(e) => setPaymentStyle(e.target.value)}
                                >

                                    <option>--- Select ---</option>
                                    <option>By Month</option>
                                    <option>By Year</option>


                                </CFormSelect>
                              </CCol>

                              <CCol xs={12}>
                                <CFormLabel htmlFor="formFileLg">Description</CFormLabel>
                                <ReactQuill
                                  formats={formats}
                                  modules={modules}
                                  theme="snow"
                                  required
                                  value={description}
                                  onChange={setDescription}
                                />
                              </CCol>

                              <CCol xs={12} className="d-flex justify-content-end">
                                <CButton
                                  size="lg"
                                  style={{
                                    backgroundColor: '#232324de',
                                    color: '#e99313',
                                    borderColor: '#e99313',
                                  }}
                                  type="submit"
                                >
                                  Submit
                                </CButton>
                              </CCol>
                            </CForm>
                          </CCardBody>
                        </CCard>
                      </CCol>
                    </CRow>
                  </MDBCardBody>
                </MDBCard>
              </MDBCol>
            </MDBRow>
          </CCardBody>
        </CModalBody>
      </CModal>

     

      <CRow>
        <CCol xs={12}>
          <CCallout className="bg-white"></CCallout>
        </CCol>
        <CCol xs={12}>
          <CCard className="mb-4">
            <CCardHeader className="" style={{ backgroundColor: '#232324de', color: '#e99313' }}>
              <CRow>
                <CCol sm={10}>
                  <strong>Degafi Setting</strong> <small>List</small>
                </CCol>
                <CCol sm={2} className="d-flex justify-content-end">
                  <CButton
                    className="text-right bg-white"
                    onClick={() => setVisibleXL(true)}
                    style={{ color: '#e99313', borderColor: '#e99313' }}
                    type="submit"
                  >
                    Add Degafi Setting
                  </CButton>
                </CCol>
              </CRow>
            </CCardHeader>

            <CCardBody>
              <CTable align="middle" className="mb-0 border" hover responsive>
                <CTableHead color="light">
                  <CTableRow>
                    
                  
                    <CTableHeaderCell>Name</CTableHeaderCell>
                    <CTableHeaderCell>Description</CTableHeaderCell>
                    <CTableHeaderCell>Money</CTableHeaderCell>
                    <CTableHeaderCell>Payment Style</CTableHeaderCell>
                    <CTableHeaderCell>Details</CTableHeaderCell>
                  </CTableRow>
                </CTableHead>
                <CTableBody>
                  {degafiSetting.map((item, index) => (
                    <CTableRow v-for="item in tableItems" key={index}>
                      
                      <CTableDataCell>{item.name}</CTableDataCell>
                      <CTableDataCell>
                        <div dangerouslySetInnerHTML={{ __html: item.description }}></div>
                      </CTableDataCell>

                      <CTableDataCell>{item.money}</CTableDataCell>
                      <CTableDataCell>{item.paymentStyle}</CTableDataCell>

                      <CTableDataCell>
                        <CButton
                          style={{
                            backgroundColor: '#232324de',
                            color: '#e99313',
                            borderColor: '#e99313',
                          }}
                          onClick={() => {
                            deleteDegafi(item.id)
                            //setDegafi(item)
                          }}
                        >
                          <CIcon icon={cilTrash} />
                          &nbsp; Remove
                        </CButton>
                      </CTableDataCell>
                    </CTableRow>
                  ))}
                </CTableBody>
              </CTable>
            </CCardBody>
          </CCard>
        </CCol>
      </CRow>
    </>
  )
}

export default DegafiSetting
