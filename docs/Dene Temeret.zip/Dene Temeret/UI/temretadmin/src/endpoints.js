const baseURL = process.env.REACT_APP_API_URL;

export const urlNews = `${baseURL}/api/news`;
export const urlMahber = `${baseURL}/api/mahber`;
export const urlusers = `${baseURL}/api/users`;
export const urlVideos = `${baseURL}/api/videos`;
export const urlMember = `${baseURL}/api/member`;
export const urlMatch = `${baseURL}/api/matches`;
export const urlTmretExec = `${baseURL}/api/tmretexc`;
export const urlAdvert = `${baseURL}/api/advert`;
export const urlDegafiSetting = `${baseURL}/api/degafisetting`;
export const assetUrl = baseURL