import React from 'react'

const Dashboard = React.lazy(() => import('./views/dashboard/Dashboard'))

const TmretExec = React.lazy(() => import('./views/tmret/tmretexec/TmretExec'))
const TmretExecCreate = React.lazy(() => import('./views/tmret/tmretexec/TmretExecCreate'))
const TmretExecEdit = React.lazy(() => import('./views/tmret/tmretexec/TmretExecEdit'))

const Mahber = React.lazy(() => import('./views/tmret/mahber/Mahber'))
const MahberProfile = React.lazy(() => import('./views/tmret/mahber/MahberProfile'))

const NewsCreate = React.lazy(() => import('./views/tmret/news/NewsCreate'))
const News = React.lazy(() => import('./views/tmret/news/News'))
const NewsEdit = React.lazy(() => import('./views/tmret/news/NewsEdit'))

const Advert = React.lazy(() => import('./views/tmret/advert/Advert'))

const VideoCreate = React.lazy(() => import('./views/video/VideosCreate'))
const Video = React.lazy(() => import('./views/video/Videos'))

const Member = React.lazy(() => import('./views/member/Member'))
const MemberCreate = React.lazy(() => import('./views/member/MemberCreate'))

const Match = React.lazy(() => import('./views/tmret/match/Match'))
const MatchCreate = React.lazy(() => import('./views/tmret/match/MatchCreate'))
const MatchUpdate = React.lazy(()=>import('./views/tmret/match/MatchEdit'))




const DegafiSettting = React.lazy(()=>import('./views/mahber/degafi/DegafiSetting'))

const routes = [
  { path: '/', exact: true, name: 'Home' },
  { path: '/dashboard', name: 'Dashboard', element: Dashboard },

  //tmretexec
  { path: '/tmretexec', name: 'Tmret Executives', exact: true, element: TmretExec },
  { path: '/tmretexec/create', name: 'Add Tmret Executives', element: TmretExecCreate },
  { path: '/tmretexec/edit', name: 'Edit Tmret Executives', element: TmretExecEdit },

  //mahber
  { path: '/mahber', name: 'mahber', element: Mahber, exact: true },
  { path: '/mahber/profile', name: 'Profile', element: MahberProfile },

  //news
  { path: '/news', name: 'News', element: News, exact: true },
  { path: '/news/create', name: 'Add News', element: NewsCreate },
  { path: '/news/edit', name: 'Edit News', element: NewsEdit },

  //advert
  { path: '/advert', name: 'Advert', element: Advert, exact: true },

  //videos
  { path: '/videos', name: 'Video', element: Video, exact: true },
  { path: '/videos/create', name: 'Add Video', element: VideoCreate },

  //member
  { path: '/members', name: 'Members', element: Member, exact: true },
  { path: '/members/create', name: 'Add Member', element: MemberCreate },

  //member
  { path: '/match', name: 'Match', element: Match, exact: true },
  { path: '/match/create', name: 'Add Match', element: MatchCreate },
  { path: '/match/update', name: 'Update Match', element:MatchUpdate},



  //mahber
  //degafi setting 
  {path: '/mahber/degafisetting', name:"Degafi Setting", element: DegafiSettting}
]

export default routes
