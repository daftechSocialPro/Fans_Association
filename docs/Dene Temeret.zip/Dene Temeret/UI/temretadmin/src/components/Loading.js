import React from 'react'
import './Loadin.css'
function Loading() {
  return (
 <div className='cardd'>
        <div className="lds-facebook "><div></div><div></div><div></div></div>
        </div>

    
  )
}

export default Loading