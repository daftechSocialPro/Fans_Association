import React,{useState,useEffect} from 'react'
import {assetUrl, urlNews} from '../endpoints'
import axios from 'axios';
import {useNavigate} from'react-router-dom'
import dateformat from 'dateformat'
function News() {
    const [news, setNews]=useState([]);
    const navigate =useNavigate();
    useEffect(()=>{


        axios.get(`${urlNews}`).then((res)=>{

            console.log(res.data)

            setNews(res.data)
          
            

        })
      

    },[])

    const getImage =(item)=>{

        return `${assetUrl}/${item}`
    }

    const newsDetails =(e,item)=>{
        e.preventDefault()
        console.log(item)

        navigate(
            '/news', {
                state:{
                news: item,
                newsList:news.slice(0,6 )
                }
                
              }

        )


    }

  return (
    <main id="mainContent" tabindex="0">
    



	


	<section data-script="pl_filtered-list" data-widget="filtered-content-list" data-page-size="10" data-ignore-tags="true" data-content-type="text" data-page="0" data-tags="News" data-references="" class="latestFeatures">

        <header class="pageHero">
            <div class="wrapper col-12">
        	       <h2 class="pageTitle">ዜና</h2>
                <div class="searchContentContainer" ></div>
                <div class="right" data-script="pl_social-share" data-widget="social-page-share" data-render="pagehover"></div>
            </div>
        </header>

        <div class="wrapper col-12">
			<section class="pageFilter" data-use-history="true" data-filter-config="editorial" data-widget="tables-filter" data-reset-available="true"></section>

			<ul class="newsList contentListContainer">

            {news.map((item)=>
	<li>
		<section class="featuredArticle">
			<div class="col-10-m">
				<a onClick={(e)=> newsDetails(e,item) } class="thumbnail thumbLong">
					<figure>
						<span class="image thumbCrop-news-list">
								<img src={getImage(item.img)} alt={item.title}/>
						</span>
				        <figcaption>
							<span class="title">{item.title}</span>
								<span class="tag">{item.subTitle}</span>
				            <span class="text"><div dangerouslySetInnerHTML={{ __html: item.description }}></div></span>
				    	</figcaption>
				    </figure>
				</a>
			</div>
			<div class="col-3-m">
					<div class="relatedArticles">
	<a href="video/single/2803579.html"  class="relatedArticle video">
		<p>
			published on : {dateformat(item.createdAt)}
		</p>
	</a>

					</div>
			</div>
		</section>
	</li>
            )}
	
	
			</ul>
		</div>
	</section>

</main>

  )
}

export default News