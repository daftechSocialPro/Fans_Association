import React, {  useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import dateformat from 'dateformat'
import { assetUrl } from '../endpoints';
function NewsDetails() {

  const location = useLocation();
  const [news,setNews]=useState(location.state.news );


  
  const newsList = location.state && location.state.newsList

  const getImage=(item) =>{

      return `${assetUrl}/${item}`

  }



  return (
    <main id="mainContent" tabindex="0">


      






      <header class="articleHeader  ">
        <div class="wrapper">
          <div class="col-8">
            <div class="articleHeaderContent">
              <h5 class="newsTag">Statistics</h5>
              <h1 class="articleTitle">{news&&news.title}</h1>
              <h5>
                <span class="articleAuth"></span>
                {news&& dateformat(news.createdAt)}
              </h5>
            </div>
          </div>
        </div>
      </header>


      <div class="wrapper">
        <div class="col-9">

          <section class="standardArticle   " data-script="pl_news-article" data-widget="article-body" data-title="Goals galore puts scoring record under threat" data-id="2798649" data-category="Statistics">

            <div class="socialShareSticky">
              <div class="socialShareHover articleShare">
                <div data-script="pl_social-share" data-widget="social-page-share" data-open="true" data-render="pagehover" data-body="Goals galore puts scoring record under threat" ></div>
              </div>
            </div>

            <div data-script="pl_editorial-lists" data-widget="video-list" class="articleImage">
              <img src={getImage(news.img)} alt="CHEWHU Antonio goal cropped" />
            </div>


            <h4 class="subHeader"> {news&&news.subTitle} </h4>

            <div class="col-12">
              <div class="relatedArticles">
                <p class="relatedArticlesText"></p>
                <div class="relatedArticlesWrapper">
                  <div class="col-3">
                    <a href="2802637.html" class="relatedArticle text">
                      <span class="type text"></span>
                      <span class="articleLead">
                       
                      </span>
                    </a>
                  </div>
                  <div class="col-3">
                    <a href="../video/single/2754675.html" class="relatedArticle video">
                      <span class="type video"></span>
                      <span class="articleLead">
                     
                      </span>
                    </a>
                  </div>
                  <div class="col-3">
                    <a href="../video/single/2799516.html" class="relatedArticle video">
                      <span class="type video"></span>
                      <span class="articleLead">
                        
                      </span>
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <p class="copy">
              <p><div dangerouslySetInnerHTML={{ __html: news.description }}></div></p>
              </p>
          </section>




          <section class="mainWidget latestFeatures ">

            <header>
              <h3 class="subHeader">ቅርብ ጊዜ ዜናዎች</h3>
            </header>



            <ul class="block-list-4" data-widget="lazy-load">

            {newsList.map((item,index)=>(

         
<li key={item.id} className="article-thumb js-content-load" data-initialised="true">


<a onClick={()=>setNews(item)} className="thumbnail">
    <figure>
        <span className="image thumbCrop-latestnews">

            <img className="article-thumb__img" src={getImage(item.img)} alt="CHEWHU Antonio goal cropped" />

        </span>
        <figcaption>


            <span className="tag">ስታትስቲክስ</span>
            <span className="title">{item.title}</span>
        </figcaption>
    </figure>
</a>
<div className="relatedArticles">

    <a  className="relatedArticle club text">
        <p>
            {item.subTitle}
        </p>
    </a>

   
</div>
</li>
            ))}
           
            </ul>



            <Link class="btn moreBtn widget-button" to="/newslist">ተጨማሪ ዜናዎች<span class="visuallyHidden"></span><span class="icn arrow-right"></span></Link>
          </section>






        </div>
        <div class="col-3">
          <div class="articleSidebar">

          </div>
        </div>
        <div class="col-12">

        </div>
      </div>
    </main>
  )
}

export default NewsDetails