
import { BrowserRouter, Route,Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import News from './pages/News';
import NewsDetails from './pages/NewsDetails';
import Mahber from './pages/Mahber';

function App() {
  return (

    <BrowserRouter>
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="newslist" element={<News /> }/>
        <Route path="news" element={<NewsDetails />} />
        <Route path='mahber' element={<Mahber/> }/> 
      </Route>
     
    </Routes>
  </BrowserRouter>
  );
}

export default App;
