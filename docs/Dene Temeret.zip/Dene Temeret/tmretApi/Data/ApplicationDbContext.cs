using System.Diagnostics.CodeAnalysis;
using Microsoft.EntityFrameworkCore;
using tmretApi.Entities;

namespace tmretApi.Data
{



    public class ApplicationDbContext : DbContext
    {

        public ApplicationDbContext([NotNullAttribute] DbContextOptions options) : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<News> News { get; set; }
        public DbSet<Advertisement> Advertisements { get; set; }
        public DbSet<DegafiMahber> DefafiMahbers { get; set; }
        public DbSet<DegafiMahberExecutive> DegafiMahberMembers { get; set; }
        public DbSet<SubscribedUsers> SubscribedUsers { get; set; }

        public DbSet<TmretExecutives> TmretExecutives { get; set; }

        public DbSet<Matches>Matches{get;set;}

        public DbSet<DegafiSetting> DegafiSettings {get;set;}

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasIndex(e => e.email).IsUnique();
            });

           
        }
    }





}