using tmretApi.Data;
using tmretApi.Services.Advert;
using tmretApi.Services.TemretExecutive;

namespace tmretApi.Services
{
    public class UnitOfWork : IUnitOfWork
    {
        private ApplicationDbContext _db;

        public UnitOfWork(ApplicationDbContext db)
        {
            _db = db;
            newsRepository = new NewsRepository(db);
            userRepository = new UserRepository(db);
            mahberRepository = new MahberRepository(db);
            memberRepository = new MemberRepository(db);
            matchRepository =new MatchRepository(db);
            temretExecutiveRepostiory = new TmretExecutiveRepository(db);
            advertRepository = new AdvertRepository(db);
            degafiSettingRepository= new DegafiSettingRepository(db);

        }
        public INewsRepository newsRepository { get; private set; }
        public IUserRepository userRepository {get;set;}

        public IMahberRepository mahberRepository {get;set;}

        public IMemberRepository memberRepository {get;set;}
        public IMatchRepository matchRepository{get;set;}

        public ITemretExecutiveRepostiory temretExecutiveRepostiory { get; set; }

        public IAdvertRepository advertRepository {get;set;}
    
        public IDegafiSettingRepository degafiSettingRepository{ get;set; }
        public async Task SaveChanges()
        {
            try
            {
                await _db.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}

