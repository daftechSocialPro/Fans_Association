using tmretApi.Entities;


namespace tmretApi.Services
{
    public interface IMatchRepository
    {

   

        Matches Create (Matches matches);


        List<Matches>  GetByWeek (int gameWeek);

        Task Update(Matches match);
        Task Delete(Guid matchId);
        List<Matches> GetAll ();

    }
}