using tmretApi.Dtos;
using tmretApi.Data;
using tmretApi.Entities;
using tmretApi.Helpers;
using System.Data.Entity;

namespace tmretApi.Services
{


    public class MatchRepository : IMatchRepository
    {

        private readonly ApplicationDbContext _context;
        public MatchRepository(ApplicationDbContext context)
        {
            _context = context;

        }




        public Matches Create(Matches Match)
        {
            
                 _context.Add(Match);
                 _context.SaveChanges();
                return Match;
                    
        }



        public List<Matches> GetByWeek(int gameWeek)
        {


            return _context.Matches.Where(m => m.matchWeek == gameWeek).ToList();
        }

        public List<Matches> GetAll()
        {



            return _context.Matches.ToList();
        }

        public async Task Update(Matches match)
        {
            try
            {

                var meaches = _context.Matches.Find(match.ID);

                meaches.matchWeek = match.matchWeek;
                meaches.team1 = match.team1;
                meaches.team1Abb = match.team1Abb;
                meaches.team2 = match.team2;
                meaches.team2Abb = match.team2Abb;
                meaches.date = match.date;
                meaches.time = match.time;
                meaches.updatedAt = DateTime.UtcNow;


               _context.Matches.Update(meaches);
               await _context.SaveChangesAsync();


            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }




        }

        public async Task Delete(Guid matchId)
        {
            try
            {
                var match = await _context.Matches.FindAsync(matchId);
                _context.Matches.Remove(match);
                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                throw new Exception(ex.Message);
            }
        }
    }
}