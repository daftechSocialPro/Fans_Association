

using tmretApi.Services.Advert;
using tmretApi.Services.TemretExecutive;

namespace tmretApi.Services
{
    public interface IUnitOfWork
    {
        INewsRepository newsRepository { get; }
        IUserRepository userRepository { get; }

        IMahberRepository mahberRepository { get; }

        IMemberRepository memberRepository {get;}

        IMatchRepository matchRepository {get;}

        ITemretExecutiveRepostiory temretExecutiveRepostiory { get;  }

        IAdvertRepository advertRepository { get; }

        IDegafiSettingRepository degafiSettingRepository {get;}
        
       


        Task SaveChanges();
    }
}
