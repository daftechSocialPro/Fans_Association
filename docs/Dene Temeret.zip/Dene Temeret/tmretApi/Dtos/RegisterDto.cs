namespace tmretApi.Dtos{


    public class RegisterDto {

        public string fullName {get;set;}
        public string email {get;set;}

        public string password {get;set;}
    }
}