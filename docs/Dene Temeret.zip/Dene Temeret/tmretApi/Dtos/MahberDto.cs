namespace tmretApi.Dtos{


    public class MahberDto{

        public string name {get; set;} 
        public string email {get;set;}
    }
}