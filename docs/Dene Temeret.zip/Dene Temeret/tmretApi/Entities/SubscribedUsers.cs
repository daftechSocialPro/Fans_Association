namespace tmretApi.Entities{


    public class SubscribedUsers{

        public Guid ID {get;set;}
        public string email {get;set;}
        public DateTime subscribedDate {get;set;}
    }
}