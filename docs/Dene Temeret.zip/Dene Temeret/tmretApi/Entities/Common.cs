﻿namespace tmretApi.Entities
{
    public class Common
    {

        public Guid ID { get; set; }

        public Guid createdBy { get; set; }

        public DateTime createdAt { get; set; }

        public DateTime updatedAt { get; set; }


       
    }
}
