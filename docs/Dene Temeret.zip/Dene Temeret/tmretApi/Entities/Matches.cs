namespace tmretApi.Entities
{

public class Matches :Common {


 
    public string team1 {get;set;}

    public string team1Abb {get;set;}

    public string team2 {get;set;}

    public string team2Abb {get;set;}

    public string date {get;set;}

    public string time {get;set;}

    public int matchWeek {get;set;}
}

}