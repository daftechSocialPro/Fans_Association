using Microsoft.AspNetCore.Mvc;
using tmretApi.Services;
using tmretApi.Dtos;
using tmretApi.Entities;
using tmretApi.Helpers;

using MlkPwgen;

namespace tmretApi.Controllers
{
    [Route("api/matches")]


    public class MatchController : Controller
    {

        private readonly IUnitOfWork _unitofwork;
        private readonly JwtService _jwtService;
        public MatchController(IUnitOfWork unitofwork , JwtService jwtService)
        {

            _unitofwork = unitofwork;
            _jwtService = jwtService;   

        }

        [HttpGet("getbyWeek")]

        public ActionResult<List<Matches>> GetById(int gameWeek)
        {


            return _unitofwork.matchRepository.GetByWeek(gameWeek);

        }

        [HttpPost]

        public IActionResult Register([FromBody] Matches Match)
        {



            Matches match = new Matches
            {

                ID = Guid.NewGuid(),
                team1 = Match.team1,
                team1Abb = Match.team1Abb,
                team2 = Match.team2,
                team2Abb = Match.team2Abb,
                date = Match.date,
                time = Match.time,
                matchWeek = Match.matchWeek
                

            };





            return Created("Success", _unitofwork.matchRepository.Create(match));



        }




        [HttpGet]
        public ActionResult<List<Matches>> GetAll()
        {


            return _unitofwork.matchRepository.GetAll();

        }


        [HttpPut]
        public async Task<ActionResult> Update([FromBody] Matches match)
        {

            try
            {

                var jwt = Request.Cookies["jwt"];
                var token = _jwtService.verify(jwt);
                Guid userId = Guid.Parse(token.Issuer);


                match.createdBy = userId;
                


                await _unitofwork.matchRepository.Update(match);
                
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

                return Unauthorized();
            }

            return NoContent();





        }

        [HttpDelete]

        public async Task<ActionResult> Delete(Guid matchId)
        {

            try
            {
                await _unitofwork.matchRepository.Delete(matchId);


            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);

                return Unauthorized();
            }

            return NoContent();



        }


    }
}